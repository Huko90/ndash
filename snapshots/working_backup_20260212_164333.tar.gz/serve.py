#!/usr/bin/env python3
"""Simple HTTP server for BTC Ticker Kiosk"""
import http.server
import socketserver
import os
import json
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

PORT = 8888
DIRECTORY = "/home/niko/btctracker"
PC_ENDPOINT = os.environ.get("BTCT_PC_ENDPOINT", "http://192.168.0.118:8085/data.json")

os.chdir(DIRECTORY)

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def do_GET(self):
        if self.path == "/api/pc":
            self._handle_pc_proxy()
            return
        super().do_GET()

    def _handle_pc_proxy(self):
        req = Request(PC_ENDPOINT, headers={"User-Agent": "btcticker-proxy/1.0"})
        try:
            with urlopen(req, timeout=5) as upstream:
                payload = upstream.read()
                status = upstream.getcode() or 200
        except (HTTPError, URLError, TimeoutError, ValueError) as exc:
            self.send_response(502)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            error = {"error": "pc_endpoint_unreachable", "detail": str(exc)}
            self.wfile.write(json.dumps(error).encode("utf-8"))
            return

        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        pass  # Suppress logging

with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
    print(f"Serving BTC Ticker at http://0.0.0.0:{PORT}")
    httpd.serve_forever()
